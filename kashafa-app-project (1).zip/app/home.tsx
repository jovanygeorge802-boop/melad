import { router } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';

export default function Home() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>الرئيسية</Text>
      <Text style={styles.welcome}>أهلاً بك في Kashafa App 👋</Text>

      <View style={styles.card}><Text style={styles.cardTitle}>📚 المناهج والمحتوى</Text><Text>الدروس والمواد التعليمية</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>📝 الاختبارات</Text><Text>اختبارات ومسابقات وتقييمات</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>📅 الأنشطة والمعسكرات</Text><Text>تابع الفعاليات والأنشطة القادمة</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>🏆 الإنجازات</Text><Text>النقاط والشارات والتقدم</Text></View>

      <Pressable style={styles.button} onPress={() => router.replace('/')}>
        <Text style={styles.buttonText}>تسجيل الخروج</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, paddingTop: 70, backgroundColor: '#fff' },
  title: { fontSize: 32, fontWeight: '800', marginBottom: 8 },
  welcome: { fontSize: 18, color: '#666', marginBottom: 24 },
  card: { padding: 18, borderWidth: 1, borderColor: '#e5e5e5', borderRadius: 16, marginBottom: 12 },
  cardTitle: { fontSize: 18, fontWeight: '800', marginBottom: 6 },
  button: { marginTop: 10, backgroundColor: '#111', padding: 15, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 17, fontWeight: '700' }
});
