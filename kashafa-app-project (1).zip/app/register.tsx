import { useState } from 'react';
import { router } from 'expo-router';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { supabase } from '../lib/supabase';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'scout' | 'church'>('scout');

  async function register() {
    if (!name || !email || !password) return Alert.alert('تنبيه', 'املأ جميع البيانات.');
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name, field: role } }
    });
    if (error) return Alert.alert('خطأ', error.message);
    Alert.alert('تم', 'تم إنشاء الحساب. تحقق من بريدك الإلكتروني إذا طُلب ذلك.');
    router.replace('/login');
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>إنشاء حساب</Text>
      <TextInput style={styles.input} placeholder="الاسم" value={name} onChangeText={setName} />
      <TextInput style={styles.input} placeholder="البريد الإلكتروني" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
      <TextInput style={styles.input} placeholder="كلمة المرور" value={password} onChangeText={setPassword} secureTextEntry />

      <Text style={styles.label}>اختر المجال</Text>
      <View style={styles.row}>
        <Pressable style={[styles.choice, role === 'scout' && styles.selected]} onPress={() => setRole('scout')}>
          <Text>⚜️ كشافة</Text>
        </Pressable>
        <Pressable style={[styles.choice, role === 'church' && styles.selected]} onPress={() => setRole('church')}>
          <Text>⛪ خدمة كنسية</Text>
        </Pressable>
      </View>

      <Pressable style={styles.button} onPress={register}><Text style={styles.buttonText}>إنشاء الحساب</Text></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#fff' },
  title: { fontSize: 30, fontWeight: '800', marginBottom: 24, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 12, padding: 15, marginBottom: 12, fontSize: 16 },
  label: { fontSize: 17, fontWeight: '700', marginTop: 8, marginBottom: 10 },
  row: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  choice: { flex: 1, padding: 15, borderWidth: 1, borderColor: '#ddd', borderRadius: 12, alignItems: 'center' },
  selected: { borderColor: '#111', backgroundColor: '#f2f2f2' },
  button: { backgroundColor: '#111', padding: 16, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: '700' }
});
