import { router } from 'expo-router';
import { StyleSheet, Text, View, Pressable } from 'react-native';

export default function Home() {
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>⚜️</Text>
      <Text style={styles.title}>كشافة App</Text>
      <Text style={styles.subtitle}>منصة الكشافة والخدمة الكنسية</Text>

      <Pressable style={styles.button} onPress={() => router.push('/login')}>
        <Text style={styles.buttonText}>تسجيل الدخول</Text>
      </Pressable>

      <Pressable style={styles.secondary} onPress={() => router.push('/register')}>
        <Text style={styles.secondaryText}>إنشاء حساب جديد</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: '#fff' },
  logo: { fontSize: 64, marginBottom: 12 },
  title: { fontSize: 32, fontWeight: '800', marginBottom: 8 },
  subtitle: { fontSize: 17, color: '#666', textAlign: 'center', marginBottom: 36 },
  button: { width: '100%', padding: 16, borderRadius: 14, backgroundColor: '#111', alignItems: 'center', marginBottom: 12 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  secondary: { width: '100%', padding: 16, borderRadius: 14, borderWidth: 1, borderColor: '#ddd', alignItems: 'center' },
  secondaryText: { fontSize: 18, fontWeight: '700' }
});
